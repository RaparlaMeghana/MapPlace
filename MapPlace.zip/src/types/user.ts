export interface User {
  id: string;
  username: string;
  email: string;
  favoriteLocations: string[];
  visitedLocations: string[];
}
