export interface SavedLocation {
  id: string;
  name: string;
  lat: number;
  lng: number;
  timestamp: number;
}
