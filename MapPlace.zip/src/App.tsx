import './index.css';
import { useState, useEffect } from 'react';
import { MapPin, Moon, Sun } from 'lucide-react';
import MapPlaceholder from './components/MapPlaceholder';
import Login from './components/Login';
import Dashboard from './components/Dashboard';

type View = 'login' | 'dashboard' | 'map';

function App() {
  const [currentView, setCurrentView] = useState<View>('login');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const user = localStorage.getItem('user');
    const isDark = localStorage.getItem('darkMode') === 'true';
    if (user) {
      setIsLoggedIn(true);
      setCurrentView('dashboard');
    }
    setDarkMode(isDark);
    if (isDark) {
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
    localStorage.setItem('darkMode', (!darkMode).toString());
  };

  const handleLogin = () => {
    setIsLoggedIn(true);
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    localStorage.removeItem('user');
    setIsLoggedIn(false);
    setCurrentView('login');
  };

  const renderView = () => {
    switch (currentView) {
      case 'login':
        return <Login onLogin={handleLogin} />;
      case 'dashboard':
        return <Dashboard onNavigate={setCurrentView} />;
      case 'map':
        return (
          <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
            <div className="bg-white dark:bg-dark-200 rounded-xl shadow-sm overflow-hidden">
              <MapPlaceholder
                savedLocations={[]}
                onLocationSelect={() => {}}
              />
            </div>
          </main>
        );
      default:
        return <Login onLogin={handleLogin} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-dark-100 transition-colors duration-200">
      {isLoggedIn && (
        <header className="bg-white dark:bg-dark-200 shadow-sm sticky top-0 z-10">
          <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MapPin className="w-6 h-6 text-blue-600" />
                <h1 className="text-xl font-bold text-gray-900 dark:text-white">MapMates</h1>
              </div>
              <nav className="flex items-center gap-6">
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className={`text-sm ${
                    currentView === 'dashboard'
                      ? 'text-blue-600'
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  Dashboard
                </button>
                <button
                  onClick={() => setCurrentView('map')}
                  className={`text-sm ${
                    currentView === 'map'
                      ? 'text-blue-600'
                      : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                  }`}
                >
                  Map
                </button>
                <button
                  onClick={handleLogout}
                  className="text-sm text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
                >
                  Logout
                </button>
                <button
                  onClick={toggleDarkMode}
                  className="p-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 rounded-full"
                >
                  {darkMode ? (
                    <Sun className="w-5 h-5" />
                  ) : (
                    <Moon className="w-5 h-5" />
                  )}
                </button>
              </nav>
            </div>
          </div>
        </header>
      )}

      {renderView()}
    </div>
  );
}

export default App;
