export interface IndianLocation {
  id: string;
  name: string;
  city: string;
  state: string;
  lat: number;
  lng: number;
  description: string;
  category: 'Historical' | 'Religious' | 'Nature' | 'Modern';
  visits: number;
}

export const popularIndianLocations: IndianLocation[] = [
  {
    id: '1',
    name: 'Qutub Minar',
    city: 'New Delhi',
    state: 'Delhi',
    lat: 28.5244,
    lng: 77.1855,
    description: 'A UNESCO World Heritage site featuring a 73-meter tall minaret built in 1193',
    category: 'Historical',
    visits: 6500000
  },
  {
    id: '2',
    name: 'Meenakshi Temple',
    city: 'Madurai',
    state: 'Tamil Nadu',
    lat: 9.9195,
    lng: 78.1193,
    description: 'A historic Hindu temple known for its stunning architecture and sculptures',
    category: 'Religious',
    visits: 4500000
  },
  {
    id: '3',
    name: 'Valley of Flowers',
    city: 'Chamoli',
    state: 'Uttarakhand',
    lat: 30.7273,
    lng: 79.6050,
    description: 'National park known for its meadows of endemic alpine flowers',
    category: 'Nature',
    visits: 2000000
  },
  {
    id: '4',
    name: 'Mysore Palace',
    city: 'Mysore',
    state: 'Karnataka',
    lat: 12.3052,
    lng: 76.6552,
    description: 'A historical palace and the former royal residence of the Wodeyar dynasty',
    category: 'Historical',
    visits: 3800000
  },
  {
    id: '5',
    name: 'Cyber Hub',
    city: 'Gurugram',
    state: 'Haryana',
    lat: 28.4949,
    lng: 77.0879,
    description: 'Modern entertainment and business hub featuring restaurants and offices',
    category: 'Modern',
    visits: 5500000
  }
];
