import { SavedLocation } from '../types/location';
import { MapPin, Trash2, Clock } from 'lucide-react';

interface LocationListProps {
  locations: SavedLocation[];
  onDelete: (id: string) => void;
}

export default function LocationList({ locations, onDelete }: LocationListProps) {
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-gray-900">Saved Locations</h2>
        <span className="text-sm text-gray-500">{locations.length} places</span>
      </div>
      <div className="space-y-3">
        {locations.map((location) => (
          <div
            key={location.id}
            className="group relative flex flex-col p-4 bg-white rounded-lg border border-gray-100 hover:border-blue-100 transition-all"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3">
                <div className="mt-1">
                  <MapPin className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">{location.name}</h3>
                  <p className="text-sm text-gray-500 mt-1">
                    {location.lat.toFixed(4)}, {location.lng.toFixed(4)}
                  </p>
                  <div className="flex items-center gap-1 mt-2 text-xs text-gray-400">
                    <Clock className="w-3 h-3" />
                    <span>{formatDate(location.timestamp)}</span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => onDelete(location.id)}
                className="opacity-0 group-hover:opacity-100 p-2 text-red-500 hover:bg-red-50 rounded-full transition-all"
                aria-label="Delete location"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
        {locations.length === 0 && (
          <div className="text-center py-8">
            <MapPin className="w-8 h-8 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500 text-sm">
              No locations saved yet.<br />Click on the map to add your first place!
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
