import { useState, useCallback } from 'react';
import { GoogleMap, Marker, useLoadScript } from '@react-google-maps/api';
import { SavedLocation } from '../types/location';
import { MapPin } from 'lucide-react';
import toast from 'react-hot-toast';

const center = { lat: 20.5937, lng: 78.9629 }; // Center of India
const MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

interface MapComponentProps {
  savedLocations: SavedLocation[];
  onLocationSelect: (lat: number, lng: number) => void;
}

const categoryColors = {
  'Historical': 'blue',
  'Religious': 'purple',
  'Nature': 'green',
  'Modern': 'orange'
} as const;

export default function Map({ savedLocations, onLocationSelect }: MapComponentProps) {
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: MAPS_API_KEY,
  });

  const [selectedMarker, setSelectedMarker] = useState<SavedLocation | null>(null);

  const onMapClick = useCallback((event: google.maps.MapMouseEvent) => {
    if (event.latLng) {
      onLocationSelect(event.latLng.lat(), event.latLng.lng());
    }
  }, [onLocationSelect]);

  const handleMarkerClick = (location: SavedLocation) => {
    setSelectedMarker(location);
    // Show a toast with location details
    toast(
      <div className="flex flex-col">
        <span className="font-medium">{location.name}</span>
        <span className="text-sm text-gray-500">
          Added {new Date(location.timestamp).toLocaleDateString()}
        </span>
      </div>,
      {
        icon: '📍',
        duration: 3000,
      }
    );
  };

  if (loadError) {
    return (
      <div className="h-[600px] w-full flex items-center justify-center bg-gray-100">
        <div className="text-center p-8">
          <MapPin className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-800 mb-2">Error Loading Map</h3>
          <p className="text-gray-600">Please check your internet connection and try again.</p>
        </div>
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className="h-[600px] w-full flex items-center justify-center bg-gray-100">
        <div className="text-center p-8">
          <MapPin className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-pulse" />
          <h3 className="text-xl font-semibold text-gray-800">Loading Map...</h3>
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-[600px] w-full">
      <GoogleMap
        zoom={5}
        center={center}
        mapContainerClassName="w-full h-full rounded-xl"
        onClick={onMapClick}
        options={{
          styles: [
            {
              featureType: "water",
              elementType: "geometry",
              stylers: [{ color: "#e9e9e9" }]
            },
            {
              featureType: "landscape",
              elementType: "geometry",
              stylers: [{ color: "#f5f5f5" }]
            },
            {
              featureType: "road",
              elementType: "geometry",
              stylers: [{ color: "#ffffff" }]
            },
            {
              featureType: "poi",
              elementType: "labels",
              stylers: [{ visibility: "off" }]
            }
          ],
          zoomControl: true,
          mapTypeControl: true,
          streetViewControl: true,
          fullscreenControl: true,
        }}
      >
        {savedLocations.map((location) => (
          <Marker
            key={location.id}
            position={{ lat: location.lat, lng: location.lng }}
            title={location.name}
            animation={google.maps.Animation.DROP}
            onClick={() => handleMarkerClick(location)}
            icon={{
              url: `data:image/svg+xml,${encodeURIComponent(`
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" fill="${
                    categoryColors[location.category as keyof typeof categoryColors] || '#4A5568'
                  }"/>
                </svg>
              `)}`,
              scaledSize: new google.maps.Size(32, 32),
              anchor: new google.maps.Point(16, 32),
            }}
          />
        ))}
      </GoogleMap>

      {/* Legend */}
      <div className="absolute bottom-4 right-4 bg-white p-3 rounded-lg shadow-sm">
        <div className="text-sm font-medium mb-2">Location Types</div>
        <div className="space-y-2">
          {Object.entries(categoryColors).map(([category, color]) => (
            <div key={category} className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full bg-${color}-500`} />
              <span className="text-xs text-gray-600">{category}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
