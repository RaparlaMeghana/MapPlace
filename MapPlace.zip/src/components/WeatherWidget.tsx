import { useEffect, useState } from 'react';
import { Cloud, Sun, CloudRain, Wind } from 'lucide-react';

interface WeatherData {
  temperature: number;
  condition: 'sunny' | 'cloudy' | 'rainy' | 'windy';
  humidity: number;
  windSpeed: number;
}

interface WeatherWidgetProps {
  location: string;
}

export default function WeatherWidget({ location }: WeatherWidgetProps) {
  const [weather, setWeather] = useState<WeatherData>({
    temperature: 28,
    condition: 'sunny',
    humidity: 65,
    windSpeed: 12,
  });

  const getWeatherIcon = (condition: string) => {
    switch (condition) {
      case 'sunny':
        return <Sun className="w-12 h-12 text-yellow-500" />;
      case 'cloudy':
        return <Cloud className="w-12 h-12 text-gray-500" />;
      case 'rainy':
        return <CloudRain className="w-12 h-12 text-blue-500" />;
      case 'windy':
        return <Wind className="w-12 h-12 text-blue-300" />;
      default:
        return <Sun className="w-12 h-12 text-yellow-500" />;
    }
  };

  return (
    <div className="flex flex-col h-full">
      <h2 className="text-xl font-semibold mb-6 text-gray-900 dark:text-white">Weather at Popular Spots</h2>
      
      <div className="space-y-6">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-medium text-lg text-gray-900 dark:text-white">{location}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Current Weather</p>
            </div>
            {getWeatherIcon(weather.condition)}
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/80 dark:bg-dark-300/80 rounded-lg p-3">
              <p className="text-sm text-gray-600 dark:text-gray-400">Temperature</p>
              <p className="text-xl font-semibold text-gray-900 dark:text-white">{weather.temperature}°C</p>
            </div>
            <div className="bg-white/80 dark:bg-dark-300/80 rounded-lg p-3">
              <p className="text-sm text-gray-600 dark:text-gray-400">Humidity</p>
              <p className="text-xl font-semibold text-gray-900 dark:text-white">{weather.humidity}%</p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-300 rounded-lg">
            <span className="text-gray-900 dark:text-white">Mumbai</span>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-gray-900 dark:text-white">32°C</span>
              <Sun className="w-4 h-4 text-yellow-500" />
            </div>
          </div>
          <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-300 rounded-lg">
            <span className="text-gray-900 dark:text-white">Bangalore</span>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-gray-900 dark:text-white">24°C</span>
              <Cloud className="w-4 h-4 text-gray-500" />
            </div>
          </div>
          <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-300 rounded-lg">
            <span className="text-gray-900 dark:text-white">Kolkata</span>
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium text-gray-900 dark:text-white">30°C</span>
              <CloudRain className="w-4 h-4 text-blue-500" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
