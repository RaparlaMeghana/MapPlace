import { useEffect, useState } from 'react';
import { MapPin, Heart, Navigation, Cloud, Share2, Search } from 'lucide-react';
import { IndianLocation, popularIndianLocations } from '../data/indianLocations';
import { User } from '../types/user';
import WeatherWidget from './WeatherWidget';
import StatsCard from './StatsCard';
import SearchBox from './SearchBox';
import toast from 'react-hot-toast';

interface DashboardProps {
  onNavigate: (view: string) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const [user, setUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredLocations, setFilteredLocations] = useState(popularIndianLocations);

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (!userData) {
      onNavigate('login');
      return;
    }
    setUser(JSON.parse(userData));
  }, [onNavigate]);

  useEffect(() => {
    const filtered = popularIndianLocations.filter(location =>
      location.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      location.city.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredLocations(filtered);
  }, [searchTerm]);

  const handleShare = (location: IndianLocation) => {
    const shareText = `Check out ${location.name} in ${location.city}, ${location.state}!`;
    if (navigator.share) {
      navigator.share({
        title: 'MapMates Location',
        text: shareText,
        url: `https://mapmates.app/location/${location.id}`,
      }).catch(() => {
        navigator.clipboard.writeText(shareText);
        toast.success('Location link copied to clipboard!');
      });
    } else {
      navigator.clipboard.writeText(shareText);
      toast.success('Location link copied to clipboard!');
    }
  };

  const userStats = {
    savedLocations: user?.favoriteLocations.length || 0,
    visitedPlaces: user?.visitedLocations.length || 0,
    totalDistance: Math.floor(Math.random() * 1000),
    achievements: ['Explorer Badge', 'Photo Master', '10 Cities Visited'],
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-dark-100 py-6 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Welcome back, {user?.username}! 👋
          </h1>
          <p className="mt-1 text-gray-500 dark:text-gray-400">
            Your personal travel companion for exploring India
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <StatsCard
            title="Saved Places"
            value={userStats.savedLocations}
            icon={<Heart className="w-5 h-5 text-pink-500" />}
            trend="+5% from last month"
          />
          <StatsCard
            title="Places Visited"
            value={userStats.visitedPlaces}
            icon={<MapPin className="w-5 h-5 text-blue-500" />}
            trend="+12% from last month"
          />
          <StatsCard
            title="Total Distance"
            value={`${userStats.totalDistance}km`}
            icon={<Navigation className="w-5 h-5 text-green-500" />}
            trend="+8% from last month"
          />
          <StatsCard
            title="Achievements"
            value={userStats.achievements.length}
            icon={<Cloud className="w-5 h-5 text-purple-500" />}
            trend="3 new this month"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 bg-white dark:bg-dark-200 rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Popular Destinations</h2>
              <SearchBox value={searchTerm} onChange={setSearchTerm} />
            </div>
            <div className="space-y-4">
              {filteredLocations.slice(0, 5).map((location) => (
                <div
                  key={location.id}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-dark-300 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-400 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-lg ${
                      location.category === 'Historical' ? 'bg-blue-100 dark:bg-blue-900' :
                      location.category === 'Religious' ? 'bg-purple-100 dark:bg-purple-900' :
                      location.category === 'Nature' ? 'bg-green-100 dark:bg-green-900' :
                      'bg-orange-100 dark:bg-orange-900'
                    }`}>
                      <MapPin className={`w-5 h-5 ${
                        location.category === 'Historical' ? 'text-blue-600' :
                        location.category === 'Religious' ? 'text-purple-600' :
                        location.category === 'Nature' ? 'text-green-600' :
                        'text-orange-600'
                      }`} />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900 dark:text-white">{location.name}</h3>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {location.city}, {location.state}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {(location.visits / 1000000).toFixed(1)}M visits
                    </span>
                    <button
                      onClick={() => handleShare(location)}
                      className="p-2 hover:bg-gray-200 dark:hover:bg-dark-400 rounded-full transition-colors"
                    >
                      <Share2 className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white dark:bg-dark-200 rounded-xl shadow-sm p-6">
            <WeatherWidget location="New Delhi" />
          </div>
        </div>
      </div>
    </div>
  );
}
