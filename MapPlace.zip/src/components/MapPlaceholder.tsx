import { MapPin } from 'lucide-react';
import { SavedLocation } from '../types/location';

interface MapPlaceholderProps {
  savedLocations: SavedLocation[];
  onLocationSelect: (lat: number, lng: number) => void;
}

export default function MapPlaceholder({ savedLocations, onLocationSelect }: MapPlaceholderProps) {
  // Sample markers to make the map look more realistic
  const sampleMarkers = [
    { x: 20, y: 30 },
    { x: 45, y: 55 },
    { x: 70, y: 25 },
    { x: 80, y: 70 },
    { x: 30, y: 80 },
  ];

  return (
    <div className="relative h-[600px] w-full overflow-hidden">
      {/* Map background image */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('https://maps.googleapis.com/maps/api/staticmap?center=20.5937,78.9629&zoom=4&size=1200x800&scale=2&style=feature:water%7Celement:geometry%7Ccolor:0xE9E9E9&style=feature:landscape%7Celement:geometry%7Ccolor:0xF5F5F5&style=feature:road%7Celement:geometry%7Ccolor:0xFFFFFF&style=feature:poi%7Celement:geometry%7Ccolor:0xF5F5F5&style=feature:transit%7Celement:geometry%7Ccolor:0xF5F5F5&style=feature:administrative%7Celement:geometry%7Ccolor:0xF5F5F5')`
        }}
      />
      
      {/* Overlay for better contrast */}
      <div className="absolute inset-0 bg-blue-50/30"></div>

      {/* Grid overlay for map-like appearance */}
      <div className="absolute inset-0 grid grid-cols-8 grid-rows-8">
        {Array.from({ length: 64 }).map((_, i) => (
          <div key={i} className="border border-blue-200/10"></div>
        ))}
      </div>

      {/* Sample markers */}
      {sampleMarkers.map((marker, index) => (
        <div
          key={index}
          className="absolute animate-pulse"
          style={{
            left: `${marker.x}%`,
            top: `${marker.y}%`,
          }}
        >
          <MapPin className="w-6 h-6 text-blue-600" />
        </div>
      ))}

      {/* Compass rose */}
      <div className="absolute top-4 right-4 bg-white/90 p-3 rounded-full shadow-sm">
        <div className="relative w-8 h-8">
          <div className="absolute inset-0 text-blue-600 font-semibold text-sm flex items-center justify-center">
            N
          </div>
        </div>
      </div>

      {/* Scale bar */}
      <div className="absolute bottom-4 left-4 bg-white/90 px-3 py-1 rounded-md shadow-sm text-xs text-gray-600">
        500 km
      </div>
    </div>
  );
}
