/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        dark: {
          100: '#1a1b1e',
          200: '#2c2e33',
          300: '#3d4048',
          400: '#5c5f6b',
        }
      }
    },
  },
  plugins: [],
}
